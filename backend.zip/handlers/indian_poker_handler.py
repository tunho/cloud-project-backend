from threading import Timer
from flask_socketio import emit
from extensions import socketio
from handlers.base_handler import GameHandler
from utils import get_room, find_player_by_sid

class IndianPokerHandler(GameHandler):
    def start_turn(self, room_id: str, gs, force_hidden=False):
        print(f"🎬 [Handler] start_turn called for {room_id}")
        
        # 🔥 [FIX] Cancel existing timer immediately to prevent zombie timers
        if hasattr(gs, 'turn_timer') and gs.turn_timer:
            gs.turn_timer.cancel()
            gs.turn_timer = None

        logic = gs.game_state
        
        # 🔥 [FIX] Sync Logic Players with Room Players (Handle Reconnects/Replacements)
        room_uids = [p.uid for p in gs.players]
        logic_uids = [p.uid for p in logic.players]
        
        if set(room_uids) != set(logic_uids):
            print(f"⚠️ [Sync] Player mismatch detected! Room: {room_uids}, Logic: {logic_uids}")
            logic.players = gs.players # Update reference
            
            # Sync Chips & Hands
            for p in gs.players:
                if p.uid not in logic.chips:
                    logic.chips[p.uid] = 100 # Default for new player
                if p.uid not in logic.hands:
                    logic.hands[p.uid] = None
            
            # Remove stale data
            logic.chips = {k: v for k, v in logic.chips.items() if k in room_uids}
            logic.hands = {k: v for k, v in logic.hands.items() if k in room_uids}
            logic.current_bets = {k: v for k, v in logic.current_bets.items() if k in room_uids}
            
            print(f"✅ [Sync] Logic state updated. Chips keys: {list(logic.chips.keys())}")

        # If round just ended, wait a bit then start new round
        if logic.phase == 'SHOWDOWN':
             # Logic to auto-start next round or wait for user is handled in client/events
             pass
        
        current_player = logic.get_current_player()
        
        # Start Timer
        if logic.phase == 'BETTING':
            # Cancel existing timer if any
            if hasattr(gs, 'turn_timer') and gs.turn_timer:
                gs.turn_timer.cancel()
            
            gs.turn_timer = Timer(30.0, self._handle_timeout, [room_id, gs])
            gs.turn_timer.start()

        self._broadcast_state(room_id, gs)

    def _broadcast_state(self, room_id: str, gs, force_hidden: bool = False):
        logic = gs.game_state
        current_player = logic.get_current_player()
        
        # Broadcast state individually to show opponent's card but hide own
        for player in gs.players:
            # Construct hands view for this player
            hands_view = {}
            if logic.phase == 'SHOWDOWN' and not force_hidden:
                hands_view = logic.hands
            else:
                for p in gs.players:
                    if p.uid == player.uid:
                        hands_view[p.uid] = 'HIDDEN' # Hide my card
                    else:
                        hands_view[p.uid] = logic.hands.get(p.uid) # Show opponent card
            
            # Serialize players for frontend
            serialized_players = []
            for p in gs.players:
                serialized_players.append({
                    "uid": p.uid,
                    "nickname": p.nickname,
                    "character": p.character if p.character else {},
                    "sid": p.sid,
                    "money": p.money, 
                    "betAmount": logic.current_bets.get(p.uid, 0),
                    "entryBet": p.bet_amount,
                    "major": getattr(p, 'major', 'Unknown'),
                    "year": getattr(p, 'year', 0)
                })

            socketio.emit("indian_poker:update_state", {
                "round": logic.current_round,
                "pot": logic.pot,
                "chips": logic.chips,
                "currentBets": logic.current_bets,
                "currentTurnUid": current_player.uid if current_player else None,
                "phase": logic.phase,
                "hands": hands_view,
                "lastAction": logic.betting_history[-1] if logic.betting_history else None,
                "timeLeft": 30,
                "players": serialized_players
            }, room=player.sid)

    def handle_action(self, room_id: str, action: str, data: dict, sid: str):
        if action == "bet":
            self._handle_bet(room_id, data, sid)
        elif action == "next_round":
            self._start_next_round(room_id, sid)
        elif action == "surrender":
            # 🔥 [FIX] Handle explicit surrender (Exit button)
            self.leave_game(room_id, sid)

    def _handle_bet(self, room_id: str, data: dict, sid: str):
        gs = get_room(room_id)
        player = find_player_by_sid(gs, sid)
        logic = gs.game_state
        
        if logic.get_current_player().uid != player.uid:
            return

        action = data.get('action')
        amount = data.get('amount', 0)
        bet_label = data.get('betLabel') # Extract bet label (Quarter, Half, etc.)

        if not action:
            return

        success, message = logic.process_bet(player.uid, action, amount, bet_label)
        
        if success:
            # Always broadcast state first to show the action (Call, Fold, etc.)
            # Force hidden hands even if phase is SHOWDOWN, to delay reveal until round_result
            self.start_turn(room_id, gs, force_hidden=True)

            if logic.phase == 'SHOWDOWN' or logic.phase == 'GAME_OVER':
                # Round/Game Ended
                self._broadcast_result(room_id, gs, logic)

    def _broadcast_result(self, room_id: str, gs, logic):
        # Reveal all cards
        socketio.emit("indian_poker:round_result", {
            "hands": logic.hands,
            "winnerUid": logic.winner.uid if logic.winner else None,
            "pot": logic.pot,
            "chips": logic.chips,
            "gameOver": logic.game_over,
            "round": logic.current_round
        }, room=room_id)
        
        if logic.game_over:
            self._handle_game_over(room_id, gs, logic)
    def on_disconnect(self, room_id: str, sid: str):
        print(f"🔌 [IndianPoker] on_disconnect: {sid} in room {room_id}")
        self.leave_game(room_id, sid)

    def leave_game(self, room_id: str, sid: str):
        gs = get_room(room_id)
        player = find_player_by_sid(gs, sid)
        if not player:
            return

        print(f"🚪 [IndianPoker] Player {player.nickname} leaving game.")
        logic = gs.game_state
        
        # If game is already over, just remove player (handled by base/general)
        if logic.phase == 'GAME_OVER':
            return

        # 🔥 [FIX] Cancel timer when player leaves
        if hasattr(gs, 'turn_timer') and gs.turn_timer:
            gs.turn_timer.cancel()
            gs.turn_timer = None

        # Immediate Defeat Logic
        # The leaver loses, the opponent wins.
        opponent = next((p for p in gs.players if p.uid != player.uid), None)
        
        if opponent:
            print(f"🏆 [IndianPoker] Opponent {opponent.nickname} wins by default.")
            
            # 🔥 [FIX] Transfer all chips to winner for "200:0" visual
            loser_chips = logic.chips.get(player.uid, 0)
            print(f"💰 [Debug] Transferring chips. Loser ({player.nickname}): {loser_chips}, Pot: {logic.pot}")
            
            logic.chips[opponent.uid] += loser_chips
            logic.chips[player.uid] = 0
            
            # 🔥 [FIX] Also transfer pot to winner (198 -> 200)
            logic.chips[opponent.uid] += logic.pot
            logic.pot = 0
            
            print(f"💰 [Debug] Chips After Transfer: {logic.chips}")

            logic.winner = opponent
            logic.game_over = True
            logic.phase = 'GAME_OVER'
            
            # End game immediately
            self._handle_game_over(room_id, gs, logic, reason="player_left")
        else:
            print("⚠️ [IndianPoker] No opponent found. Game ends without winner.")

    def _handle_timeout(self, room_id, gs):
        logic = gs.game_state
        current_player = logic.get_current_player()
        
        if not current_player:
            print(f"⚠️ Timeout triggered but no current player found in room {room_id}")
            return

        print(f"⏰ Turn Timeout: {current_player.nickname}")
        
        # Auto Fold on timeout with 'DIE' label
        self._handle_bet(room_id, {'action': 'FOLD', 'betLabel': 'DIE'}, current_player.sid)

    def _start_next_round(self, room_id: str, sid):
        gs = get_room(room_id)
        logic = gs.game_state
        logic.start_round()
        self.start_turn(room_id, gs)

    def _handle_game_over(self, room_id: str, gs, logic, reason="normal"):
        # 🔥 [FIX] Cancel timer on game over
        if hasattr(gs, 'turn_timer') and gs.turn_timer:
            gs.turn_timer.cancel()
            gs.turn_timer = None

        # Final Payout Logic
        winner = logic.winner
        if winner:
            winner.final_rank = 1
            loser = gs.players[1] if winner == gs.players[0] else gs.players[0]
            loser.final_rank = 2
            
            from game_events import handle_winnings
            payout_results = handle_winnings(room_id)
            
            # Determine Reason if not provided
            if reason == "normal":
                if logic.current_round >= 10:
                    reason = "turn_limit"
                elif any(p.money <= 0 for p in logic.players):
                    reason = "bankruptcy"

            # Robust Winner Data
            winner_data = {
                "uid": winner.uid,
                "nickname": getattr(winner, 'nickname', 'Unknown'),
                "character": getattr(winner, 'character', {})
            }
            print(f"🏁 [IndianPoker] Game Over. Winner: {winner_data}, Reason: {reason}")
            
            # 🔥 [FIX] Force 200:0 display for early termination (Bankruptcy/Surrender)
            # This ensures the UI shows a clean "Winner Takes All" state.
            if logic.current_round < 10:
                print(f"💰 [IndianPoker] Early termination (Round {logic.current_round}). Forcing 200:0 chips.")
                logic.chips[winner.uid] = 200
                logic.chips[loser.uid] = 0
                logic.pot = 0 # Ensure pot is empty

            # 🔥 [FIX] Broadcast final state so frontend sees 200:0 chips
            self._broadcast_state(room_id, gs)

            socketio.emit("game_over", {
                "winner": winner_data,
                "payouts": payout_results,
                "reason": reason
            }, room=room_id)
